PATH=.packaged_python/python/bin:$PATH
python3 thebox.py