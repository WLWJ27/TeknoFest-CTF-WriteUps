import hashlib

import requests

import base64

NOT_THE_FLAG = "flag{this-is-not-the-droid-youre-looking-for}"

Flag = 'Savvy{cfcd208495d565ef66e7dff9f98764da}'

Flag = 'Savvy{c4ca4238a0b923820dcc509a6f75849b}'

Flag = 'Savvy{c81e728d9d4c2f636f067f89cc14862c}'

Flag = 'Savvy{eccbc87e4b5ce2fe28308fd9f2a7baf3}'

Flag = 'Savvy{a87ff679a2f3e71d9181a67b7542122c}'

Flag = 'Savvy{e4da3b7fbbce2345d7772b0674a318d5}'

Flag = 'Savvy{1679091c5a880faf6fb5e6087eb1b2dc}'

Flag = 'Savvy{8f14e45fceea167a5a36dedd4bea2543}'

Flag = 'Savvy{c9f0f895fb98ab9159f51fd0297e236d}'

Flag = 'Savvy{45c48cce2e2d7fbdea1afc51c7c6ad26}'

Flag = 'Savvy{d3d9446802a44259755d38e6d163e820}'

Flag = 'Savvy{6512bd43d9caa6e02c990b0a82652dca}'

Flag = 'Savvy{c20ad4d76fe97759aa27a0c99bff6710}'

Flag = 'Savvy{c51ce410c124a10e0db5e4b97fc2af39}'

Flag = 'Savvy{aab3238922bcc25a6f606eb525ffdc56}'

Flag = 'Savvy{9bf31c7ff062936a96d3c8bd1f8f2ff3}'

Flag = 'Savvy{c74d97b01eae257e44aa9d5bade97baf}'

Flag = 'Savvy{70efdf2ec9b086079795c442636b55fb}'

Flag = 'Savvy{6f4922f45568161a8cdf4ad2299f6d23}'

Flag = 'Savvy{1f0e3dad99908345f7439f8ffabdffc4}'

Flag = 'Savvy{98f13708210194c475687be6106a3b84}'

Flag = 'Savvy{3c59dc048e8850243be8079a5c74d079}'

Flag = 'Savvy{b6d767d2f8ed5d21a44b0e5886680cb9}'

Flag = 'Savvy{37693cfc748049e45d87b8c7d8b9aacd}'

Flag = 'Savvy{1ff1de774005f8da13f42943881c655f}'

Flag = 'Savvy{8e296a067a37563370ded05f5a3bf3ec}'

Flag = 'Savvy{4e732ced3463d06de0ca9a15b6153677}'

Flag = 'Savvy{02e74f10e0327ad868d138f2b4fdd6f0}'

Flag = 'Savvy{33e75ff09dd601bbe69f351039152189}'

Flag = 'Savvy{6ea9ab1baa0efb9e19094440c317e21b}'

Flag = 'Savvy{34173cb38f07f89ddbebc2ac9128303f}'

Flag = 'Savvy{c16a5320fa475530d9583c34fd356ef5}'

Flag = 'Savvy{6364d3f0f495b6ab9dcf8d3b5c6e0b01}'

Flag = 'Savvy{182be0c5cdcd5072bb1864cdee4d3d6e}'

Flag = 'Savvy{e369853df766fa44e1ed0ff613f563bd}'

Flag = 'Savvy{1c383cd30b7c298ab50293adfecb7b18}'

Flag = 'Savvy{19ca14e7ea6328a42e0eb13d585e4c22}'

Flag = 'Savvy{a5bfc9e07964f8dddeb95fc584cd965d}'

Flag = 'Savvy{a5771bce93e200c36f7cd9dfd0e5deaa}'

Flag = 'Savvy{d67d8ab4f4c10bf22aa353e27879133c}'

Flag = 'Savvy{d645920e395fedad7bbbed0eca3fe2e0}'

Flag = 'Savvy{3416a75f4cea9109507cacd8e2f2aefc}'

Flag = 'Savvy{a1d0c6e83f027327d8461063f4ac58a6}'

Flag = 'Savvy{17e62166fc8586dfa4d1bc0e1742c08b}'

Flag = 'Savvy{f7177163c833dff4b38fc8d2872f1ec6}'

Flag = 'Savvy{6c8349cc7260ae62e3b1396831a8398f}'

Flag = 'Savvy{d9d4f495e875a2e075a1a4a6e1b9770f}'

Flag = 'Savvy{67c6a1e7ce56d3d6fa748ab6d9af3fd7}'

Flag = 'Savvy{642e92efb79421734881b53e1e1b18b6}'

Flag = 'Savvy{f457c545a9ded88f18ecee47145a72c0}'

Flag = 'Savvy{c0c7c76d30bd3dcaefc96f40275bdc0a}'

Flag = 'Savvy{2838023a778dfaecdc212708f721b788}'

Flag = 'Savvy{9a1158154dfa42caddbd0694a4e9bdc8}'

Flag = 'Savvy{d82c8d1619ad8176d665453cfb2e55f0}'

Flag = 'Savvy{a684eceee76fc522773286a895bc8436}'

Flag = 'Savvy{b53b3a3d6ab90ce0268229151c9bde11}'

Flag = 'Savvy{9f61408e3afb633e50cdf1b20de6f466}'

Flag = 'Savvy{72b32a1f754ba1c09b3695e0cb6cde7f}'

Flag = 'Savvy{66f041e16a60928b05a7e228a89c3799}'

Flag = 'Savvy{093f65e080a295f8076b1c5722a46aa2}'

Flag = 'Savvy{072b030ba126b2f4b2374f342be9ed44}'

Flag = 'Savvy{7f39f8317fbdb1988ef4c628eba02591}'

Flag = 'Savvy{44f683a84163b3523afe57c2e008bc8c}'

Flag = 'Savvy{03afdbd66e7929b125f8597834fa83a4}'

Flag = 'Savvy{ea5d2f1c4608232e07d3aa3d998e5135}'

Flag = 'Savvy{fc490ca45c00b1249bbe3554a4fdf6fb}'

Flag = 'Savvy{3295c76acbf4caaed33c36b1b5fc2cb1}'

Flag = 'Savvy{735b90b4568125ed6c3f678819b6e058}'

Flag = 'Savvy{a3f390d88e4c41f2747bfa2f1b5f87db}'

Flag = 'Savvy{14bfa6bb14875e45bba028a21ed38046}'

Flag = 'Savvy{7cbbc409ec990f19c78c75bd1e06f215}'

Flag = 'Savvy{e2c420d928d4bf8ce0ff2ec19b371514}'

Flag = 'Savvy{32bb90e8976aab5298d5da10fe66f21d}'

Flag = 'Savvy{d2ddea18f00665ce8623e36bd4e3c7c5}'

Flag = 'Savvy{ad61ab143223efbc24c7d2583be69251}'

Flag = 'Savvy{d09bf41544a3365a46c9077ebb5e35c3}'

Flag = 'Savvy{fbd7939d674997cdb4692d34de8633c4}'

Flag = 'Savvy{28dd2c7955ce926456240b2ff0100bde}'

Flag = 'Savvy{35f4a8d465e6e1edc05f3d8ab658c551}'

Flag = 'Savvy{d1fe173d08e959397adf34b1d77e88d7}'

Flag = 'Savvy{f033ab37c30201f73f142449d037028d}'

Flag = 'Savvy{43ec517d68b6edd3015b3edc9a11367b}'

Flag = 'Savvy{9778d5d219c5080b9a6a17bef029331c}'

Flag = 'Savvy{fe9fc289c3ff0af142b6d3bead98a923}'

Flag = 'Savvy{68d30a9594728bc39aa24be94b319d21}'

Flag = 'Savvy{3ef815416f775098fe977004015c6193}'

Flag = 'Savvy{93db85ed909c13838ff95ccfa94cebd9}'

Flag = 'Savvy{c7e1249ffc03eb9ded908c236bd1996d}'

Flag = 'Savvy{2a38a4a9316c49e5a833517c45d31070}'

Flag = 'Savvy{7647966b7343c29048673252e490f736}'

Flag = 'Savvy{8613985ec49eb8f757ae6439e879bb2a}'

Flag = 'Savvy{54229abfcfa5649e7003b83dd4755294}'

Flag = 'Savvy{92cc227532d17e56e07902b254dfad10}'

Flag = 'Savvy{98dce83da57b0395e163467c9dae521b}'

Flag = 'Savvy{f4b9ec30ad9f68f89b29639786cb62ef}'

Flag = 'Savvy{812b4ba287f5ee0bc9d43bbf5bbe87fb}'

Flag = 'Savvy{26657d5ff9020d2abefe558796b99584}'

Flag = 'Savvy{e2ef524fbf3d9fe611d5a8e90fefdc9c}'

Flag = 'Savvy{ed3d2c21991e3bef5e069713af9fa6ca}'

Flag = 'Savvy{ac627ab1ccbdb62ec96e702f07f6425b}'

Flag = 'Savvy{f899139df5e1059396431415e770c6dd}'

Flag = 'Savvy{38b3eff8baf56627478ec76a704e9b52}'

Flag = 'Savvy{ec8956637a99787bd197eacd77acce5e}'

Flag = 'Savvy{6974ce5ac660610b44d9b9fed0ff9548}'

Flag = 'Savvy{c9e1074f5b3f9fc8ea15d152add07294}'

Flag = 'Savvy{65b9eea6e1cc6bb9f0cd2a47751a186f}'

Flag = 'Savvy{f0935e4cd5920aa6c7c996a5ee53a70f}'

Flag = 'Savvy{a97da629b098b75c294dffdc3e463904}'

Flag = 'Savvy{a3c65c2974270fd093ee8a9bf8ae7d0b}'

Flag = 'Savvy{2723d092b63885e0d7c260cc007e8b9d}'

Flag = 'Savvy{5f93f983524def3dca464469d2cf9f3e}'

Flag = 'Savvy{698d51a19d8a121ce581499d7b701668}'

Flag = 'Savvy{7f6ffaa6bb0b408017b62254211691b5}'

Flag = 'Savvy{73278a4a86960eeb576a8fd4c9ec6997}'

Flag = 'Savvy{5fd0b37cd7dbbb00f97ba6ce92bf5add}'

Flag = 'Savvy{2b44928ae11fb9384c4cf38708677c48}'

Flag = 'Savvy{c45147dee729311ef5b5c3003946c48f}'

Flag = 'Savvy{eb160de1de89d9058fcb0b968dbbbd68}'

Flag = 'Savvy{5ef059938ba799aaa845e1c2e8a762bd}'

Flag = 'Savvy{07e1cd7dca89a1678042477183b7ac3f}'

Flag = 'Savvy{da4fb5c6e93e74d3df8527599fa62642}'

Flag = 'Savvy{4c56ff4ce4aaf9573aa5dff913df997a}'

Flag = 'Savvy{a0a080f42e6f13b3a2df133f073095dd}'

Flag = 'Savvy{202cb962ac59075b964b07152d234b70}'

Flag = 'Savvy{c8ffe9a587b126f152ed3d89a146b445}'

Flag = 'Savvy{3def184ad8f4755ff269862ea77393dd}'

Flag = 'Savvy{069059b7ef840f0c74a814ec9237b6ec}'

Flag = 'Savvy{ec5decca5ed3d6b8079e2e7e7bacc9f2}'

Flag = 'Savvy{76dc611d6ebaafc66cc0879c71b5db5c}'

Flag = 'Savvy{d1f491a404d6854880943e5c3cd9ca25}'

Flag = 'Savvy{9b8619251a19057cff70779273e95aa6}'

Flag = 'Savvy{1afa34a7f984eeabdbb0a7d494132ee5}'

Flag = 'Savvy{65ded5353c5ee48d0b7d48c591b8f430}'

Flag = 'Savvy{9fc3d7152ba9336a670e36d0ed79bc43}'

Flag = 'Savvy{02522a2b2726fb0a03bb19f2d8d9524d}'

Flag = 'Savvy{7f1de29e6da19d22b51c68001e7e0e54}'

Flag = 'Savvy{42a0e188f5033bc65bf8d78622277c4e}'

Flag = 'Savvy{3988c7f88ebcb58c6ce932b957b6f332}'

Flag = 'Savvy{013d407166ec4fa56eb1e1f8cbe183b9}'

Flag = 'Savvy{e00da03b685a0dd18fb6a08af0923de0}'

Flag = 'Savvy{1385974ed5904a438616ff7bdb3f7439}'

Flag = 'Savvy{0f28b5d49b3020afeecd95b4009adf4c}'

Flag = 'Savvy{a8baa56554f96369ab93e4f3bb068c22}'

Flag = 'Savvy{903ce9225fca3e988c2af215d4e544d3}'

Flag = 'Savvy{0a09c8844ba8f0936c20bd791130d6b6}'

Flag = 'Savvy{2b24d495052a8ce66358eb576b8912c8}'

Flag = 'Savvy{a5e00132373a7031000fd987a3c9f87b}'

Flag = 'Savvy{8d5e957f297893487bd98fa830fa6413}'

Flag = 'Savvy{47d1e990583c9c67424d369f3414728e}'

Flag = 'Savvy{f2217062e9a397a1dca429e7d70bc6ca}'

Flag = 'Savvy{7ef605fc8dba5425d6965fbd4c8fbe1f}'

Flag = 'Savvy{a8f15eda80c50adb0e71943adc8015cf}'

Flag = 'Savvy{37a749d808e46495a8da1e5352d03cae}'

Flag = 'Savvy{b3e3e393c77e35a4a3f3cbd1e429b5dc}'

Flag = 'Savvy{1d7f7abc18fcb43975065399b0d1e48e}'

Flag = 'Savvy{2a79ea27c279e471f4d180b08d62b00a}'

Flag = 'Savvy{1c9ac0159c94d8d0cbedc973445af2da}'

Flag = 'Savvy{6c4b761a28b734fe93831e3fb400ce87}'

Flag = 'Savvy{06409663226af2f3114485aa4e0a23b4}'

Flag = 'Savvy{140f6969d5213fd0ece03148e62e461e}'

Flag = 'Savvy{b73ce398c39f506af761d2277d853a92}'

Flag = 'Savvy{bd4c9ab730f5513206b999ec0d90d1fb}'

Flag = 'Savvy{82aa4b0af34c2313a562076992e50aa3}'

Flag = 'Savvy{0777d5c17d4066b82ab86dff8a46af6f}'

Flag = 'Savvy{fa7cdfad1a5aaf8370ebeda47a1ff1c3}'

Flag = 'Savvy{9766527f2b5d3e95d4a733fcfb77bd7e}'

Flag = 'Savvy{7e7757b1e12abcb736ab9a754ffb617a}'

Flag = 'Savvy{5878a7ab84fb43402106c575658472fa}'

Flag = 'Savvy{006f52e9102a8d3be2fe5614f42ba989}'

Flag = 'Savvy{3636638817772e42b59d74cff571fbb3}'

Flag = 'Savvy{149e9677a5989fd342ae44213df68868}'

Flag = 'Savvy{a4a042cf4fd6bfb47701cbc8a1653ada}'

Flag = 'Savvy{1ff8a7b5dc7a7d1f0ed65aaa29c04b1e}'

Flag = 'Savvy{f7e6c85504ce6e82442c770f7c8606f0}'

Flag = 'Savvy{bf8229696f7a3bb4700cfddef19fa23f}'

Flag = 'Savvy{82161242827b703e6acf9c726942a1e4}'

Flag = 'Savvy{38af86134b65d0f10fe33d30dd76442e}'

Flag = 'Savvy{96da2f590cd7246bbde0051047b0d6f7}'

Flag = 'Savvy{8f85517967795eeef66c225f7883bdcb}'

Flag = 'Savvy{8f53295a73878494e9bc8dd6c3c7104f}'

Flag = 'Savvy{045117b0e0a11a242b9765e79cbf113f}'

Flag = 'Savvy{fc221309746013ac554571fbd180e1c8}'

Flag = 'Savvy{4c5bde74a8f110656874902f07378009}'

Flag = 'Savvy{cedebb6e872f539bef8c3f919874e9d7}'

Flag = 'Savvy{6cdd60ea0045eb7a6ec44c54d29ed402}'

Flag = 'Savvy{eecca5b6365d9607ee5a9d336962c534}'

Flag = 'Savvy{9872ed9fc22fc182d371c3e9ed316094}'

Flag = 'Savvy{31fefc0e570cb3860f2a6d4b38c6490d}'

Flag = 'Savvy{9dcb88e0137649590b755372b040afad}'

Flag = 'Savvy{a2557a7b2e94197ff767970b67041697}'

Flag = 'Savvy{cfecdb276f634854f3ef915e2e980c31}'

Flag = 'Savvy{0aa1883c6411f7873cb83dacb17b0afc}'

Flag = 'Savvy{58a2fc6ed39fd083f55d4182bf88826d}'

Flag = 'Savvy{bd686fd640be98efaae0091fa301e613}'

Flag = 'Savvy{a597e50502f5ff68e3e25b9114205d4a}'

Flag = 'Savvy{0336dcbab05b9d5ad24f4333c7658a0e}'

Flag = 'Savvy{084b6fbb10729ed4da8c3d3f5a3ae7c9}'

Flag = 'Savvy{85d8ce590ad8981ca2c8286f79f59954}'

Flag = 'Savvy{0e65972dce68dad4d52d063967f0a705}'

Flag = 'Savvy{84d9ee44e457ddef7f2c4f25dc8fa865}'

Flag = 'Savvy{3644a684f98ea8fe223c713b77189a77}'

Flag = 'Savvy{757b505cfd34c64c85ca5b5690ee5293}'

Flag = 'Savvy{854d6fae5ee42911677c739ee1734486}'

Flag = 'Savvy{e2c0be24560d78c5e599c2a9c9d0bbd2}'

Flag = 'Savvy{274ad4786c3abca69fa097b85867d9a4}'

Flag = 'Savvy{eae27d77ca20db309e056e3d2dcd7d69}'

Flag = 'Savvy{7eabe3a1649ffa2b3ff8c02ebfd5659f}'

Flag = 'Savvy{69adc1e107f7f7d035d7baf04342e1ca}'

Flag = 'Savvy{091d584fced301b442654dd8c23b3fc9}'

Flag = 'Savvy{b1d10e7bafa4421218a51b1e1f1b0ba2}'

Flag = 'Savvy{6f3ef77ac0e3619e98159e9b6febf557}'

Flag = 'Savvy{eb163727917cbba1eea208541a643e74}'

Flag = 'Savvy{1534b76d325a8f591b52d302e7181331}'

Flag = 'Savvy{979d472a84804b9f647bc185a877a8b5}'

Flag = 'Savvy{ca46c1b9512a7a8315fa3c5a946e8265}'

Flag = 'Savvy{3b8a614226a953a8cd9526fca6fe9ba5}'

Flag = 'Savvy{45fbc6d3e05ebd93369ce542e8f2322d}'

Flag = 'Savvy{63dc7ed1010d3c3b8269faf0ba7491d4}'

Flag = 'Savvy{e96ed478dab8595a7dbda4cbcbee168f}'

Flag = 'Savvy{c0e190d8267e36708f955d7ab048990d}'

Flag = 'Savvy{ec8ce6abb3e952a85b8551ba726a1227}'

Flag = 'Savvy{060ad92489947d410d897474079c1477}'

Flag = 'Savvy{bcbe3365e6ac95ea2c0343a2395834dd}'

Flag = 'Savvy{115f89503138416a242f40fb7d7f338e}'

Flag = 'Savvy{13fe9d84310e77f13a6d184dbf1232f3}'

Flag = 'Savvy{d1c38a09acc34845c6be3a127a5aacaf}'

Flag = 'Savvy{9cfdf10e8fc047a44b08ed031e1f0ed1}'

Flag = 'Savvy{705f2172834666788607efbfca35afb3}'

Flag = 'Savvy{74db120f0a8e5646ef5a30154e9f6deb}'

Flag = 'Savvy{57aeee35c98205091e18d1140e9f38cf}'

Flag = 'Savvy{6da9003b743b65f4c0ccd295cc484e57}'

Flag = 'Savvy{9b04d152845ec0a378394003c96da594}'

Flag = 'Savvy{be83ab3ecd0db773eb2dc1b0a17836a1}'

Flag = 'Savvy{e165421110ba03099a1c0393373c5b43}'

Flag = 'Savvy{289dff07669d7a23de0ef88d2f7129e7}'

Flag = 'Savvy{577ef1154f3240ad5b9b413aa7346a1e}'

Flag = 'Savvy{01161aaa0b6d1345dd8fe4e481144d84}'

Flag = 'Savvy{539fd53b59e3bb12d203f45a912eeaf2}'

Flag = 'Savvy{ac1dd209cbcc5e5d1c6e28598e8cbbe8}'

Flag = 'Savvy{555d6702c950ecb729a966504af0a635}'

Flag = 'Savvy{335f5352088d7d9bf74191e006d8e24c}'

Flag = 'Savvy{f340f1b1f65b6df5b5e3f94d95b11daf}'

Flag = 'Savvy{e4a6222cdb5b34375400904f03d8e6a5}'

Flag = 'Savvy{cb70ab375662576bd1ac5aaf16b3fca4}'

Flag = 'Savvy{9188905e74c28e489b44e954ec0b9bca}'

Flag = 'Savvy{0266e33d3f546cb5436a10798e657d97}'

Flag = 'Savvy{38db3aed920cf82ab059bfccbd02be6a}'

Flag = 'Savvy{3cec07e9ba5f5bb252d13f5f431e4bbb}'

Flag = 'Savvy{621bf66ddb7c962aa0d22ac97d69b793}'

Flag = 'Savvy{077e29b11be80ab57e1a2ecabb7da330}'

Flag = 'Savvy{6c9882bbac1c7093bd25041881277658}'

Flag = 'Savvy{19f3cd308f1455b3fa09a282e0d496f4}'

Flag = 'Savvy{03c6b06952c750899bb03d998e631860}'

Flag = 'Savvy{c24cd76e1ce41366a4bbe8a49b02a028}'

Flag = 'Savvy{c52f1bd66cc19d05628bd8bf27af3ad6}'

Flag = 'Savvy{fe131d7f5a6b38b23cc967316c13dae2}'

Flag = 'Savvy{f718499c1c8cef6730f9fd03c8125cab}'

Flag = 'Savvy{d96409bf894217686ba124d7356686c9}'

Flag = 'Savvy{502e4a16930e414107ee22b6198c578f}'

Flag = 'Savvy{cfa0860e83a4c3a763a7e62d825349f7}'

Flag = 'Savvy{a4f23670e1833f3fdb077ca70bbd5d66}'

Flag = 'Savvy{b1a59b315fc9a3002ce38bbe070ec3f5}'

Flag = 'Savvy{36660e59856b4de58a219bcf4e27eba3}'

Flag = 'Savvy{8c19f571e251e61cb8dd3612f26d5ecf}'

Flag = 'Savvy{d6baf65e0b240ce177cf70da146c8dc8}'

Flag = 'Savvy{e56954b4f6347e897f954495eab16a88}'

Flag = 'Savvy{f7664060cc52bc6f3d620bcedc94a4b6}'

Flag = 'Savvy{eda80a3d5b344bc40f3bc04f65b7a357}'

Flag = 'Savvy{8f121ce07d74717e0b1f21d122e04521}'

Flag = 'Savvy{06138bc5af6023646ede0e1f7c1eac75}'

Flag = 'Savvy{39059724f73a9969845dfe4146c5660e}'

Flag = 'Savvy{7f100b7b36092fb9b06dfb4fac360931}'

Flag = 'Savvy{7a614fd06c325499f1680b9896beedeb}'

Flag = 'Savvy{4734ba6f3de83d861c3176a6273cac6d}'

Flag = 'Savvy{d947bf06a885db0d477d707121934ff8}'

Flag = 'Savvy{63923f49e5241343aa7acb6a06a751e7}'

Flag = 'Savvy{db8e1af0cb3aca1ae2d0018624204529}'

Flag = 'Savvy{20f07591c6fcb220ffe637cda29bb3f6}'

Flag = 'Savvy{07cdfd23373b17c6b337251c22b7ea57}'

Flag = 'Savvy{d395771085aab05244a4fb8fd91bf4ee}'

Flag = 'Savvy{92c8c96e4c37100777c7190b76d28233}'

Flag = 'Savvy{e3796ae838835da0b6f6ea37bcf8bcb7}'

Flag = 'Savvy{6a9aeddfc689c1d0e3b9ccc3ab651bc5}'

Flag = 'Savvy{0f49c89d1e7298bb9930789c8ed59d48}'

Flag = 'Savvy{46ba9f2a6976570b0353203ec4474217}'

Flag = 'Savvy{0e01938fc48a2cfb5f2217fbfb00722d}'

Flag = 'Savvy{16a5cdae362b8d27a1d8f8c7b78b4330}'

Flag = 'Savvy{918317b57931b6b7a7d29490fe5ec9f9}'

Flag = 'Savvy{48aedb8880cab8c45637abc7493ecddd}'

Flag = 'Savvy{839ab46820b524afda05122893c2fe8e}'

Flag = 'Savvy{f90f2aca5c640289d0a29417bcb63a37}'

Flag = 'Savvy{9c838d2e45b2ad1094d42f4ef36764f6}'

Flag = 'Savvy{1700002963a49da13542e0726b7bb758}'

Flag = 'Savvy{53c3bce66e43be4f209556518c2fcb54}'

Flag = 'Savvy{6883966fd8f918a4aa29be29d2c386fb}'

Flag = 'Savvy{49182f81e6a13cf5eaa496d51fea6406}'

Flag = 'Savvy{d296c101daa88a51f6ca8cfc1ac79b50}'

Flag = 'Savvy{9fd81843ad7f202f26c1a174c7357585}'

Flag = 'Savvy{26e359e83860db1d11b6acca57d8ea88}'

Flag = 'Savvy{ef0d3930a7b6c95bd2b32ed45989c61f}'

Flag = 'Savvy{94f6d7e04a4d452035300f18b984988c}'

Flag = 'Savvy{34ed066df378efacc9b924ec161e7639}'

Flag = 'Savvy{577bcc914f9e55d5e4e4f82f9f00e7d4}'

Flag = 'Savvy{11b9842e0a271ff252c1903e7132cd68}'

Flag = 'Savvy{37bc2f75bf1bcfe8450a1a41c200364c}'

Flag = 'Savvy{496e05e1aea0a9c4655800e8a7b9ea28}'

Flag = 'Savvy{b2eb7349035754953b57a32e2841bda5}'

Flag = 'Savvy{8e98d81f8217304975ccb23337bb5761}'

Flag = 'Savvy{a8c88a0055f636e4a163a5e3d16adab7}'

Flag = 'Savvy{eddea82ad2755b24c4e168c5fc2ebd40}'

Flag = 'Savvy{06eb61b839a0cefee4967c67ccb099dc}'

Flag = 'Savvy{9dfcd5e558dfa04aaf37f137a1d9d3e5}'

Flag = 'Savvy{950a4152c2b4aa3ad78bdd6b366cc179}'

Flag = 'Savvy{158f3069a435b314a80bdcb024f8e422}'

Flag = 'Savvy{758874998f5bd0c393da094e1967a72b}'

Flag = 'Savvy{ad13a2a07ca4b7642959dc0c4c740ab6}'

Flag = 'Savvy{3fe94a002317b5f9259f82690aeea4cd}'

Flag = 'Savvy{5b8add2a5d98b1a652ea7fd72d942dac}'

Flag = 'Savvy{432aca3a1e345e339f35a30c8f65edce}'

Flag = 'Savvy{8d3bba7425e7c98c50f52ca1b52d3735}'

Flag = 'Savvy{320722549d1751cf3f247855f937b982}'

Flag = 'Savvy{caf1a3dfb505ffed0d024130f58c5cfa}'

Flag = 'Savvy{5737c6ec2e0716f3d8a7a5c4e0de0d9a}'

Flag = 'Savvy{bc6dc48b743dc5d013b1abaebd2faed2}'

Flag = 'Savvy{f2fc990265c712c49d51a18a32b39f0c}'

Flag = 'Savvy{89f0fd5c927d466d6ec9a21b9ac34ffa}'

Flag = 'Savvy{a666587afda6e89aec274a3657558a27}'

Flag = 'Savvy{b83aac23b9528732c23cc7352950e880}'

Flag = 'Savvy{cd00692c3bfe59267d5ecfac5310286c}'

Flag = 'Savvy{6faa8040da20ef399b63a72d0e4ab575}'

Flag = 'Savvy{fe73f687e5bc5280214e0486b273a5f9}'

Flag = 'Savvy{6da37dd3139aa4d9aa55b8d237ec5d4a}'

Flag = 'Savvy{c042f4db68f23406c6cecf84a7ebb0fe}'

Flag = 'Savvy{310dcbbf4cce62f762a2aaa148d556bd}'

Flag = 'Savvy{2f2b265625d76a6704b08093c652fd79}'

Flag = 'Savvy{f9b902fc3289af4dd08de5d1de54f68f}'

Flag = 'Savvy{6855456e2fe46a9d49d3d3af4f57443d}'

Flag = 'Savvy{357a6fdf7642bf815a88822c447d9dc4}'

Flag = 'Savvy{819f46e52c25763a55cc642422644317}'

Flag = 'Savvy{04025959b191f8f9de3f924f0940515f}'

Flag = 'Savvy{40008b9a5380fcacce3976bf7c08af5b}'

Flag = 'Savvy{3dd48ab31d016ffcbf3314df2b3cb9ce}'

Flag = 'Savvy{58238e9ae2dd305d79c2ebc8c1883422}'

Flag = 'Savvy{3ad7c2ebb96fcba7cda0cf54a2e802f5}'

Flag = 'Savvy{b3967a0e938dc2a6340e258630febd5a}'

Flag = 'Savvy{d81f9c1be2e08964bf9f24b15f0e4900}'

Flag = 'Savvy{13f9896df61279c928f19721878fac41}'

Flag = 'Savvy{c5ff2543b53f4cc0ad3819a36752467b}'

Flag = 'Savvy{01386bd6d8e091c2ab4c7c7de644d37b}'

Flag = 'Savvy{0bb4aec1710521c12ee76289d9440817}'

Flag = 'Savvy{9de6d14fff9806d4bcd1ef555be766cd}'

Flag = 'Savvy{efe937780e95574250dabe07151bdc23}'

Flag = 'Savvy{371bce7dc83817b7893bcdeed13799b5}'

Flag = 'Savvy{138bb0696595b338afbab333c555292a}'

Flag = 'Savvy{8dd48d6a2e2cad213179a3992c0be53c}'

Flag = 'Savvy{82cec96096d4281b7c95cd7e74623496}'

Flag = 'Savvy{6c524f9d5d7027454a783c841250ba71}'

Flag = 'Savvy{fb7b9ffa5462084c5f4e7e85a093e6d7}'

Flag = 'Savvy{aa942ab2bfa6ebda4840e7360ce6e7ef}'

Flag = 'Savvy{c058f544c737782deacefa532d9add4c}'

Flag = 'Savvy{e7b24b112a44fdd9ee93bdf998c6ca0e}'

Flag = 'Savvy{52720e003547c70561bf5e03b95aa99f}'

Flag = 'Savvy{c3e878e27f52e2a57ace4d9a76fd9acf}'

Flag = 'Savvy{00411460f7c92d2124a67ea0f4cb5f85}'

Flag = 'Savvy{bac9162b47c56fc8a4d2a519803d51b3}'

Flag = 'Savvy{9be40cee5b0eee1462c82c6964087ff9}'

Flag = 'Savvy{5ef698cd9fe650923ea331c15af3b160}'

Flag = 'Savvy{05049e90fa4f5039a8cadc6acbb4b2cc}'

Flag = 'Savvy{cf004fdc76fa1a4f25f62e0eb5261ca3}'

Flag = 'Savvy{0c74b7f78409a4022a2c4c5a5ca3ee19}'

Flag = 'Savvy{d709f38ef758b5066ef31b18039b8ce5}'

Flag = 'Savvy{41f1f19176d383480afa65d325c06ed0}'

Flag = 'Savvy{24b16fede9a67c9251d3e7c7161c83ac}'

Flag = 'Savvy{ffd52f3c7e12435a724a8f30fddadd9c}'

Flag = 'Savvy{ad972f10e0800b49d76fed33a21f6698}'

Flag = 'Savvy{f61d6947467ccd3aa5af24db320235dd}'

Flag = 'Savvy{142949df56ea8ae0be8b5306971900a4}'

Flag = 'Savvy{d34ab169b70c9dcd35e62896010cd9ff}'

Flag = 'Savvy{8bf1211fd4b7b94528899de0a43b9fb3}'

Flag = 'Savvy{a02ffd91ece5e7efeb46db8f10a74059}'

Flag = 'Savvy{bca82e41ee7b0833588399b1fcd177c7}'

Flag = 'Savvy{00ec53c4682d36f5c4359f4ae7bd7ba1}'

Flag = 'Savvy{4f6ffe13a5d75b2d6a3923922b3922e5}'

Flag = 'Savvy{beed13602b9b0e6ecb5b568ff5058f07}'

Flag = 'Savvy{0584ce565c824b7b7f50282d9a19945b}'

Flag = 'Savvy{dc912a253d1e9ba40e2c597ed2376640}'

Flag = 'Savvy{39461a19e9eddfb385ea76b26521ea48}'

Flag = 'Savvy{8efb100a295c0c690931222ff4467bb8}'

Flag = 'Savvy{d9fc5b73a8d78fad3d6dffe419384e70}'

Flag = 'Savvy{c86a7ee3d8ef0b551ed58e354a836f2b}'

Flag = 'Savvy{a01a0380ca3c61428c26a231f0e49a09}'

Flag = 'Savvy{5a4b25aaed25c2ee1b74de72dc03c14e}'

Flag = 'Savvy{f73b76ce8949fe29bf2a537cfa420e8f}'

Flag = 'Savvy{70c639df5e30bdee440e4cdf599fec2b}'

Flag = 'Savvy{28f0b864598a1291557bed248a998d4e}'

Flag = 'Savvy{1543843a4723ed2ab08e18053ae6dc5b}'

Flag = 'Savvy{f8c1f23d6a8d8d7904fc0ea8e066b3bb}'

Flag = 'Savvy{e46de7e1bcaaced9a54f1e9d0d2f800d}'

Flag = 'Savvy{b7b16ecf8ca53723593894116071700c}'

Flag = 'Savvy{352fe25daf686bdb4edca223c921acea}'

Flag = 'Savvy{18d8042386b79e2c279fd162df0205c8}'

Flag = 'Savvy{816b112c6105b3ebd537828a39af4818}'

Flag = 'Savvy{69cb3ea317a32c4e6143e665fdb20b14}'

Flag = 'Savvy{bbf94b34eb32268ada57a3be5062fe7d}'

Flag = 'Savvy{4f4adcbf8c6f66dcfc8a3282ac2bf10a}'

Flag = 'Savvy{bbcbff5c1f1ded46c25d28119a85c6c2}'

Flag = 'Savvy{8cb22bdd0b7ba1ab13d742e22eed8da2}'

Flag = 'Savvy{f4f6dce2f3a0f9dada0c2b5b66452017}'

Flag = 'Savvy{0d0fd7c6e093f7b804fa0150b875b868}'

Flag = 'Savvy{a96b65a721e561e1e3de768ac819ffbb}'

Flag = 'Savvy{1068c6e4c8051cfd4e9ea8072e3189e2}'

Flag = 'Savvy{17d63b1625c816c22647a73e1482372b}'

Flag = 'Savvy{b9228e0962a78b84f3d5d92f4faa000b}'

Flag = 'Savvy{0deb1c54814305ca9ad266f53bc82511}'

Flag = 'Savvy{66808e327dc79d135ba18e051673d906}'

Flag = 'Savvy{42e7aaa88b48137a16a1acd04ed91125}'

Flag = 'Savvy{8fe0093bb30d6f8c31474bd0764e6ac0}'

Flag = 'Savvy{41ae36ecb9b3eee609d05b90c14222fb}'

Flag = 'Savvy{d1f255a373a3cef72e03aa9d980c7eca}'

Flag = 'Savvy{7eacb532570ff6858afd2723755ff790}'

Flag = 'Savvy{b6f0479ae87d244975439c6124592772}'

Flag = 'Savvy{e0c641195b27425bb056ac56f8953d24}'

Flag = 'Savvy{f85454e8279be180185cac7d243c5eb3}'

Flag = 'Savvy{faa9afea49ef2ff029a833cccc778fd0}'

Flag = 'Savvy{3c7781a36bcd6cf08c11a970fbe0e2a6}'

Flag = 'Savvy{25b2822c2f5a3230abfadd476e8b04c9}'

Flag = 'Savvy{6ecbdd6ec859d284dc13885a37ce8d81}'

Flag = 'Savvy{18997733ec258a9fcaf239cc55d53363}'

Flag = 'Savvy{8d7d8ee069cb0cbbf816bbb65d56947e}'

Flag = 'Savvy{75fc093c0ee742f6dddaa13fff98f104}'

Flag = 'Savvy{f74909ace68e51891440e4da0b65a70c}'

Flag = 'Savvy{66368270ffd51418ec58bd793f2d9b1b}'

Flag = 'Savvy{248e844336797ec98478f85e7626de4a}'

Flag = 'Savvy{019d385eb67632a7e958e23f24bd07d7}'

Flag = 'Savvy{a49e9411d64ff53eccfdd09ad10a15b3}'

Flag = 'Savvy{ddb30680a691d157187ee1cf9e896d03}'

Flag = 'Savvy{2421fcb1263b9530df88f7f002e78ea5}'

Flag = 'Savvy{fccb60fb512d13df5083790d64c4d5dd}'

Flag = 'Savvy{1651cf0d2f737d7adeab84d339dbabd3}'

Flag = 'Savvy{eed5af6add95a9a6f1252739b1ad8c24}'

Flag = 'Savvy{a8abb4bb284b5b27aa7cb790dc20f80b}'

Flag = 'Savvy{15d4e891d784977cacbfcbb00c48f133}'

Flag = 'Savvy{c203d8a151612acf12457e4d67635a95}'

Flag = 'Savvy{13f3cf8c531952d72e5847c4183e6910}'

Flag = 'Savvy{550a141f12de6341fba65b0ad0433500}'

Flag = 'Savvy{67f7fb873eaf29526a11a9b7ac33bfac}'

Flag = 'Savvy{1a5b1e4daae265b790965a275b53ae50}'

Flag = 'Savvy{9a96876e2f8f3dc4f3cf45f02c61c0c1}'

Flag = 'Savvy{9b70e8fe62e40c570a322f1b0b659098}'

Flag = 'Savvy{d61e4bbd6393c9111e6526ea173a7c8b}'

Flag = 'Savvy{f5f8590cd58a54e94377e6ae2eded4d9}'

Flag = 'Savvy{941e1aaaba585b952b62c14a3a175a61}'

Flag = 'Savvy{9431c87f273e507e6040fcb07dcb4509}'

Flag = 'Savvy{49ae49a23f67c759bf4fc791ba842aa2}'

Flag = 'Savvy{e44fea3bec53bcea3b7513ccef5857ac}'

Flag = 'Savvy{821fa74b50ba3f7cba1e6c53e8fa6845}'

Flag = 'Savvy{250cf8b51c773f3f8dc8b4be867a9a02}'

Flag = 'Savvy{42998cf32d552343bc8e460416382dca}'

Flag = 'Savvy{d07e70efcfab08731a97e7b91be644de}'

Flag = 'Savvy{7fe1f8abaad094e0b5cb1b01d712f708}'

Flag = 'Savvy{98b297950041a42470269d56260243a1}'

Flag = 'Savvy{0353ab4cbed5beae847a7ff6e220b5cf}'

Flag = 'Savvy{51d92be1c60d1db1d2e5e7a07da55b26}'

Flag = 'Savvy{428fca9bc1921c25c5121f9da7815cde}'

Flag = 'Savvy{f1b6f2857fb6d44dd73c7041e0aa0f19}'

Flag = 'Savvy{68ce199ec2c5517597ce0a4d89620f55}'

Flag = 'Savvy{e836d813fd184325132fca8edcdfb40e}'

Flag = 'Savvy{ab817c9349cf9c4f6877e1894a1faa00}'

Flag = 'Savvy{877a9ba7a98f75b90a9d49f53f15a858}'

Flag = 'Savvy{dc6a6489640ca02b0d42dabeb8e46bb7}'

Flag = 'Savvy{26337353b7962f533d78c762373b3318}'

Flag = 'Savvy{8e6b42f1644ecb1327dc03ab345e618b}'

Flag = 'Savvy{ef575e8837d065a1683c022d2077d342}'

Flag = 'Savvy{2050e03ca119580f74cca14cc6e97462}'

Flag = 'Savvy{25ddc0f8c9d3e22e03d3076f98d83cb2}'

Flag = 'Savvy{5ef0b4eba35ab2d6180b0bca7e46b6f9}'

Flag = 'Savvy{598b3e71ec378bd83e0a727608b5db01}'

Flag = 'Savvy{74071a673307ca7459bcf75fbd024e09}'

Flag = 'Savvy{cfee398643cbc3dc5eefc89334cacdc1}'

Flag = 'Savvy{d18f655c3fce66ca401d5f38b48c89af}'

Flag = 'Savvy{6ea2ef7311b482724a9b7b0bc0dd85c6}'

Flag = 'Savvy{9461cce28ebe3e76fb4b931c35a169b0}'

Flag = 'Savvy{f770b62bc8f42a0b66751fe636fc6eb0}'

Flag = 'Savvy{e1e32e235eee1f970470a3a6658dfdd5}'

Flag = 'Savvy{eba0dc302bcd9a273f8bbb72be3a687b}'

Flag = 'Savvy{218a0aefd1d1a4be65601cc6ddc1520e}'

Flag = 'Savvy{7d04bbbe5494ae9d2f5a76aa1c00fa2f}'

Flag = 'Savvy{a516a87cfcaef229b342c437fe2b95f7}'

Flag = 'Savvy{c3c59e5f8b3e9753913f4d435b53c308}'

Flag = 'Savvy{854d9fca60b4bd07f9bb215d59ef5561}'

Flag = 'Savvy{c410003ef13d451727aeff9082c29a5c}'

Flag = 'Savvy{559cb990c9dffd8675f6bc2186971dc2}'

Flag = 'Savvy{55a7cf9c71f1c9c495413f934dd1a158}'

Flag = 'Savvy{2f55707d4193dc27118a0f19a1985716}'

Flag = 'Savvy{1be3bc32e6564055d5ca3e5a354acbef}'

Flag = 'Savvy{35051070e572e47d2c26c241ab88307f}'

Flag = 'Savvy{b534ba68236ba543ae44b22bd110a1d6}'

Flag = 'Savvy{7380ad8a673226ae47fce7bff88e9c33}'

Flag = 'Savvy{05f971b5ec196b8c65b75d2ef8267331}'

Flag = 'Savvy{3cf166c6b73f030b4f67eeaeba301103}'

Flag = 'Savvy{cee631121c2ec9232f3a2f028ad5c89b}'

Flag = 'Savvy{5b69b9cb83065d403869739ae7f0995e}'

Flag = 'Savvy{b5b41fac0361d157d9673ecb926af5ae}'

Flag = 'Savvy{285e19f20beded7d215102b49d5c09a0}'

Flag = 'Savvy{b337e84de8752b27eda3a12363109e80}'

Flag = 'Savvy{e8c0653fea13f91bf3c48159f7c24f78}'

Flag = 'Savvy{ff4d5fbbafdf976cfdc032e3bde78de5}'

Flag = 'Savvy{2d6cc4b2d139a53512fb8cbb3086ae2e}'

Flag = 'Savvy{389bc7bb1e1c2a5e7e147703232a88f6}'

Flag = 'Savvy{e2230b853516e7b05d79744fbd4c9c13}'

Flag = 'Savvy{087408522c31eeb1f982bc0eaf81d35f}'

Flag = 'Savvy{a760880003e7ddedfef56acb3b09697f}'

Flag = 'Savvy{10a7cdd970fe135cf4f7bb55c0e3b59f}'

Flag = 'Savvy{3dc4876f3f08201c7c76cb71fa1da439}'

Flag = 'Savvy{59b90e1005a220e2ebc542eb9d950b1e}'

Flag = 'Savvy{2b8a61594b1f4c4db0902a8a395ced93}'

Flag = 'Savvy{f3f27a324736617f20abbf2ffd806f6d}'

Flag = 'Savvy{38913e1d6a7b94cb0f55994f679f5956}'

Flag = 'Savvy{ebd9629fc3ae5e9f6611e2ee05a31cef}'

Flag = 'Savvy{63538fe6ef330c13a05a3ed7e599d5f7}'

Flag = 'Savvy{cf67355a3333e6e143439161adc2d82e}'

Flag = 'Savvy{07563a3fe3bbe7e3ba84431ad9d055af}'

Flag = 'Savvy{53fde96fcc4b4ce72d7739202324cd49}'

Flag = 'Savvy{2bb232c0b13c774965ef8558f0fbd615}'

Flag = 'Savvy{ba2fd310dcaa8781a9a652a31baf3c68}'

Flag = 'Savvy{69421f032498c97020180038fddb8e24}'

Flag = 'Savvy{85422afb467e9456013a2a51d4dff702}'

Flag = 'Savvy{13f320e7b5ead1024ac95c3b208610db}'

Flag = 'Savvy{f4be00279ee2e0a53eafdaa94a151e2c}'

Flag = 'Savvy{37f0e884fbad9667e38940169d0a3c95}'

Flag = 'Savvy{d64a340bcb633f536d56e51874281454}'

Flag = 'Savvy{0fcbc61acd0479dc77e3cccc0f5ffca7}'

Flag = 'Savvy{298f95e1bf9136124592c8d4825a06fc}'

Flag = 'Savvy{df877f3865752637daa540ea9cbc474f}'

Flag = 'Savvy{c399862d3b9d6b76c8436e924a68c45b}'

Flag = 'Savvy{33e8075e9970de0cfea955afd4644bb2}'

Flag = 'Savvy{65658fde58ab3c2b6e5132a39fae7cb9}'

Flag = 'Savvy{5ea1649a31336092c05438df996a3e59}'

Flag = 'Savvy{7bcdf75ad237b8e02e301f4091fb6bc8}'

Flag = 'Savvy{5737034557ef5b8c02c0e46513b98f90}'

Flag = 'Savvy{9b72e31dac81715466cd580a448cf823}'

Flag = 'Savvy{16c222aa19898e5058938167c8ab6c57}'

Flag = 'Savvy{7dcd340d84f762eba80aa538b0c527f7}'

Flag = 'Savvy{81448138f5f163ccdba4acc69819f280}'

Flag = 'Savvy{97e8527feaf77a97fc38f34216141515}'

Flag = 'Savvy{647bba344396e7c8170902bcf2e15551}'

Flag = 'Savvy{ed265bc903a5a097f61d3ec064d96d2e}'

Flag = 'Savvy{c75b6f114c23a4d7ea11331e7c00e73c}'

Flag = 'Savvy{8d34201a5b85900908db6cae92723617}'

Flag = 'Savvy{ccb1d45fb76f7c5a0bf619f979c6cf36}'

Flag = 'Savvy{01f78be6f7cad02658508fe4616098a9}'

Flag = 'Savvy{7f24d240521d99071c93af3917215ef7}'

Flag = 'Savvy{94c7bb58efc3b337800875b5d382a072}'

Flag = 'Savvy{f387624df552cea2f369918c5e1e12bc}'

Flag = 'Savvy{5e388103a391daabe3de1d76a6739ccd}'

Flag = 'Savvy{15de21c670ae7c3f6f3f1f37029303c9}'

Flag = 'Savvy{11b921ef080f7736089c757404650e40}'

Flag = 'Savvy{6e2713a6efee97bacb63e52c54f0ada0}'

Flag = 'Savvy{1bb91f73e9d31ea2830a5e73ce3ed328}'

Flag = 'Savvy{3a0772443a0739141292a5429b952fe6}'

Flag = 'Savvy{a9a6653e48976138166de32772b1bf40}'

Flag = 'Savvy{58ae749f25eded36f486bc85feb3f0ab}'

Flag = 'Savvy{4e4b5fbbbb602b6d35bea8460aa8f8e5}'

Flag = 'Savvy{8eefcfdf5990e441f0fb6f3fad709e21}'

Flag = 'Savvy{1728efbda81692282ba642aafd57be3a}'

Flag = 'Savvy{cbcb58ac2e496207586df2854b17995f}'

Flag = 'Savvy{db85e2590b6109813dafa101ceb2faeb}'

Flag = 'Savvy{99c5e07b4d5de9d18c350cdf64c5aa3d}'

Flag = 'Savvy{dd458505749b2941217ddd59394240e8}'

Flag = 'Savvy{8b16ebc056e613024c057be590b542eb}'

Flag = 'Savvy{a86c450b76fb8c371afead6410d55534}'

Flag = 'Savvy{c9892a989183de32e976c6f04e700201}'

Flag = 'Savvy{e6b4b2a746ed40e1af829d1fa82daa10}'

Flag = 'Savvy{e5f6ad6ce374177eef023bf5d0c018b6}'

Flag = 'Savvy{f0e52b27a7a5d6a1a87373dffa53dbe5}'

Flag = 'Savvy{ffeabd223de0d4eacb9a3e6e53e5448d}'

Flag = 'Savvy{a7aeed74714116f3b292a982238f83d2}'

Flag = 'Savvy{fde9264cf376fffe2ee4ddf4a988880d}'

Flag = 'Savvy{a8849b052492b5106526b2331e526138}'

Flag = 'Savvy{258be18e31c8188555c2ff05b4d542c3}'

Flag = 'Savvy{069d3bb002acd8d7dd095917f9efe4cb}'

Flag = 'Savvy{c6e19e830859f2cb9f7c8f8cacb8d2a6}'

Flag = 'Savvy{46922a0880a8f11f8f69cbb52b1396be}'

Flag = 'Savvy{9ad6aaed513b73148b7d49f70afcfb32}'

Flag = 'Savvy{f5deaeeae1538fb6c45901d524ee2f98}'

Flag = 'Savvy{a9a1d5317a33ae8cef33961c34144f84}'

Flag = 'Savvy{605ff764c617d3cd28dbbdd72be8f9a2}'

Flag = 'Savvy{766ebcd59621e305170616ba3d3dac32}'

Flag = 'Savvy{daca41214b39c5dc66674d09081940f0}'

Flag = 'Savvy{30bb3825e8f631cc6075c0f87bb4978c}'

Flag = 'Savvy{08b255a5d42b89b0585260b6f2360bdd}'

Flag = 'Savvy{3493894fa4ea036cfc6433c3e2ee63b0}'

Flag = 'Savvy{dbe272bab69f8e13f14b405e038deb64}'

Flag = 'Savvy{acc3e0404646c57502b480dc052c4fe1}'

Flag = 'Savvy{076a0c97d09cf1a0ec3e19c7f2529f2b}'

Flag = 'Savvy{04ecb1fa28506ccb6f72b12c0245ddbc}'

Flag = 'Savvy{b2eeb7362ef83deff5c7813a67e14f0a}'

Flag = 'Savvy{08c5433a60135c32e34f46a71175850c}'

Flag = 'Savvy{6aca97005c68f1206823815f66102863}'

Flag = 'Savvy{3435c378bb76d4357324dd7e69f3cd18}'

Flag = 'Savvy{d490d7b4576290fa60eb31b5fc917ad1}'

Flag = 'Savvy{b2f627fff19fda463cb386442eac2b3d}'

Flag = 'Savvy{c3992e9a68c5ae12bd18488bc579b30d}'

Flag = 'Savvy{d86ea612dec96096c5e0fcc8dd42ab6d}'

Flag = 'Savvy{9cf81d8026a9018052c429cc4e56739b}'

Flag = 'Savvy{c361bc7b2c033a83d663b8d9fb4be56e}'

Flag = 'Savvy{44c4c17332cace2124a1a836d9fc4b6f}'

Flag = 'Savvy{dc82d632c9fcecb0778afbc7924494a6}'

Flag = 'Savvy{996a7fa078cc36c46d02f9af3bef918b}'

Flag = 'Savvy{d7a728a67d909e714c0774e22cb806f2}'

Flag = 'Savvy{00ac8ed3b4327bdd4ebbebcb2ba10a00}'

Flag = 'Savvy{8ebda540cbcc4d7336496819a46a1b68}'

Flag = 'Savvy{f76a89f0cb91bc419542ce9fa43902dc}'

Flag = 'Savvy{f29c21d4897f78948b91f03172341b7b}'

Flag = 'Savvy{851ddf5058cf22df63d3344ad89919cf}'

Flag = 'Savvy{58d4d1e7b1e97b258c9ed0b37e02d087}'

Flag = 'Savvy{7750ca3559e5b8e1f44210283368fc16}'

Flag = 'Savvy{5d44ee6f2c3f71b73125876103c8f6c4}'

Flag = 'Savvy{eb6fdc36b281b7d5eabf33396c2683a2}'

Flag = 'Savvy{cdc0d6e63aa8e41c89689f54970bb35f}'

Flag = 'Savvy{b73dfe25b4b8714c029b37a6ad3006fa}'

Flag = 'Savvy{85fc37b18c57097425b52fc7afbb6969}'

Flag = 'Savvy{3871bd64012152bfb53fdf04b401193f}'

Flag = 'Savvy{a733fa9b25f33689e2adbe72199f0e62}'

Flag = 'Savvy{48ab2f9b45957ab574cf005eb8a76760}'

Flag = 'Savvy{233509073ed3432027d48b1a83f5fbd2}'

Flag = 'Savvy{45645a27c4f1adc8a7a835976064a86d}'

Flag = 'Savvy{185c29dc24325934ee377cfda20e414c}'

Flag = 'Savvy{42e77b63637ab381e8be5f8318cc28a2}'

Flag = 'Savvy{051e4e127b92f5d98d3c79b195f2b291}'

Flag = 'Savvy{9cc138f8dc04cbf16240daa92d8d50e2}'

Flag = 'Savvy{b7bb35b9c6ca2aee2df08cf09d7016c2}'

Flag = 'Savvy{abd815286ba1007abfbb8415b83ae2cf}'

Flag = 'Savvy{26dd0dbc6e3f4c8043749885523d6a25}'

Flag = 'Savvy{6766aa2750c19aad2fa1b32f36ed4aee}'

Flag = 'Savvy{6a10bbd480e4c5573d8f3af73ae0454b}'

Flag = 'Savvy{c5ab0bc60ac7929182aadd08703f1ec6}'

Flag = 'Savvy{a532400ed62e772b9dc0b86f46e583ff}'

Flag = 'Savvy{4c27cea8526af8cfee3be5e183ac9605}'

Flag = 'Savvy{0f96613235062963ccde717b18f97592}'

Flag = 'Savvy{4ffce04d92a4d6cb21c1494cdfcd6dc1}'

Flag = 'Savvy{67e103b0761e60683e83c559be18d40c}'

Flag = 'Savvy{291597a100aadd814d197af4f4bab3a7}'

Flag = 'Savvy{9b698eb3105bd82528f23d0c92dedfc0}'

Flag = 'Savvy{8c7bbbba95c1025975e548cee86dfadc}'

Flag = 'Savvy{5e9f92a01c986bafcabbafd145520b13}'

Flag = 'Savvy{0ff39bbbf981ac0151d340c9aa40e63e}'

Flag = 'Savvy{303ed4c69846ab36c2904d3ba8573050}'

Flag = 'Savvy{443cb001c138b2561a0d90720d6ce111}'

Flag = 'Savvy{55b37c5c270e5d84c793e486d798c01d}'

Flag = 'Savvy{884d247c6f65a96a7da4d1105d584ddd}'

Flag = 'Savvy{55743cc0393b1cb4b8b37d09ae48d097}'

Flag = 'Savvy{30ef30b64204a3088a26bc2e6ecf7602}'

Flag = 'Savvy{eaae339c4d89fc102edd9dbdb6a28915}'

Flag = 'Savvy{ab233b682ec355648e7891e66c54191b}'

Flag = 'Savvy{3d2d8ccb37df977cb6d9da15b76c3f3a}'

Flag = 'Savvy{26408ffa703a72e8ac0117e74ad46f33}'

Flag = 'Savvy{b4288d9c0ec0a1841b3b3728321e7088}'

Flag = 'Savvy{2f37d10131f2a483a8dd005b3d14b0d9}'

Flag = 'Savvy{0ff8033cf9437c213ee13937b1c4c455}'

Flag = 'Savvy{68264bdb65b97eeae6788aa3348e553c}'

Flag = 'Savvy{3a066bda8c96b9478bb0512f0a43028c}'

Flag = 'Savvy{be3159ad04564bfb90db9e32851ebf9c}'

Flag = 'Savvy{8757150decbd89b0f5442ca3db4d0e0e}'

Flag = 'Savvy{2291d2ec3b3048d1a6f86c2c4591b7e0}'

Flag = 'Savvy{84117275be999ff55a987b9381e01f96}'

Flag = 'Savvy{fae0b27c451c728867a567e8c1bb4e53}'

Flag = 'Savvy{b5dc4e5d9b495d0196f61d45b26ef33e}'

Flag = 'Savvy{192fc044e74dffea144f9ac5dc9f3395}'

Flag = 'Savvy{5c04925674920eb58467fb52ce4ef728}'

Flag = 'Savvy{17c276c8e723eb46aef576537e9d56d0}'

Flag = 'Savvy{5dd9db5e033da9c6fb5ba83c7a7ebea9}'

Flag = 'Savvy{2dea61eed4bceec564a00115c4d21334}'

Flag = 'Savvy{9f396fe44e7c05c16873b05ec425cbad}'

Flag = 'Savvy{0d7de1aca9299fe63f3e0041f02638a3}'

Flag = 'Savvy{8fecb20817b3847419bb3de39a609afe}'

Flag = 'Savvy{dc6a70712a252123c40d2adba6a11d84}'

Flag = 'Savvy{71a3cb155f8dc89bf3d0365288219936}'

Flag = 'Savvy{9fe8593a8a330607d76796b35c64c600}'

Flag = 'Savvy{ca9c267dad0305d1a6308d2a0cf1c39c}'

Flag = 'Savvy{fccb3cdc9acc14a6e70a12f74560c026}'

Flag = 'Savvy{1595af6435015c77a7149e92a551338e}'

Flag = 'Savvy{08d98638c6fcd194a4b1e6992063e944}'

Flag = 'Savvy{24681928425f5a9133504de568f5f6df}'

Flag = 'Savvy{556f391937dfd4398cbac35e050a2177}'

Flag = 'Savvy{3328bdf9a4b9504b9398284244fe97c2}'

Flag = 'Savvy{109a0ca3bc27f3e96597370d5c8cf03d}'

Flag = 'Savvy{7f5d04d189dfb634e6a85bb9d9adf21e}'

Flag = 'Savvy{f79921bbae40a577928b76d2fc3edc2a}'

Flag = 'Savvy{07a96b1f61097ccb54be14d6a47439b0}'

Flag = 'Savvy{c06d06da9666a219db15cf575aff2824}'

Flag = 'Savvy{10a5ab2db37feedfdeaab192ead4ac0e}'

Flag = 'Savvy{e555ebe0ce426f7f9b2bef0706315e0c}'

Flag = 'Savvy{53e3a7161e428b65688f14b84d61c610}'

Flag = 'Savvy{5487315b1286f907165907aa8fc96619}'

Flag = 'Savvy{e4bb4c5173c2ce17fd8fcd40041c068f}'

Flag = 'Savvy{0cb929eae7a499e50248a3a78f7acfc7}'

Flag = 'Savvy{8a0e1141fd37fa5b98d5bb769ba1a7cc}'

Flag = 'Savvy{99bcfcd754a98ce89cb86f73acc04645}'

Flag = 'Savvy{afd4836712c5e77550897e25711e1d96}'

Flag = 'Savvy{e5841df2166dd424a57127423d276bbe}'

Flag = 'Savvy{b4a528955b84f584974e92d025a75d1f}'

Flag = 'Savvy{b1eec33c726a60554bc78518d5f9b32c}'

Flag = 'Savvy{d6c651ddcd97183b2e40bc464231c962}'

Flag = 'Savvy{f64eac11f2cd8f0efa196f8ad173178e}'

Flag = 'Savvy{4a47d2983c8bd392b120b627e0e1cab4}'

Flag = 'Savvy{9c82c7143c102b71c593d98d96093fde}'

Flag = 'Savvy{500e75a036dc2d7d2fec5da1b71d36cc}'

Flag = 'Savvy{ae0eb3eed39d2bcef4622b2499a05fe6}'

Flag = 'Savvy{1ecfb463472ec9115b10c292ef8bc986}'

Flag = 'Savvy{e70611883d2760c8bbafb4acb29e3446}'

Flag = 'Savvy{6081594975a764c8e3a691fa2b3a321d}'

Flag = 'Savvy{19bc916108fc6938f52cb96f7e087941}'

Flag = 'Savvy{07c5807d0d927dcd0980f86024e5208b}'

Flag = 'Savvy{d14220ee66aeec73c49038385428ec4c}'

Flag = 'Savvy{8df707a948fac1b4a0f97aa554886ec8}'

Flag = 'Savvy{e7f8a7fb0b77bcb3b283af5be021448f}'

Flag = 'Savvy{788d986905533aba051261497ecffcbb}'

Flag = 'Savvy{50c3d7614917b24303ee6a220679dab3}'

Flag = 'Savvy{2afe4567e1bf64d32a5527244d104cea}'

Flag = 'Savvy{5f2c22cb4a5380af7ca75622a6426917}'

Flag = 'Savvy{aba3b6fd5d186d28e06ff97135cade7f}'

Flag = 'Savvy{c8ed21db4f678f3b13b9d5ee16489088}'

Flag = 'Savvy{08419be897405321542838d77f855226}'

Flag = 'Savvy{7f1171a78ce0780a2142a6eb7bc4f3c8}'

Flag = 'Savvy{82f2b308c3b01637c607ce05f52a2fed}'

Flag = 'Savvy{0d3180d672e08b4c5312dcdafdf6ef36}'

Flag = 'Savvy{fb89705ae6d743bf1e848c206e16a1d7}'

Flag = 'Savvy{d4c2e4a3297fe25a71d030b67eb83bfc}'

Flag = 'Savvy{5751ec3e9a4feab575962e78e006250d}'

Flag = 'Savvy{d5cfead94f5350c12c322b5b664544c1}'

Flag = 'Savvy{59c33016884a62116be975a9bb8257e3}'

Flag = 'Savvy{ba3866600c3540f67c1e9575e213be0a}'

Flag = 'Savvy{6c29793a140a811d0c45ce03c1c93a28}'

Flag = 'Savvy{e995f98d56967d946471af29d7bf99f1}'

Flag = 'Savvy{6cd67d9b6f0150c77bda2eda01ae484c}'

Flag = 'Savvy{6bc24fc1ab650b25b4114e93a98f1eba}'

Flag = 'Savvy{a5cdd4aa0048b187f7182f1b9ce7a6a7}'

Flag = 'Savvy{217eedd1ba8c592db97d0dbe54c7adfc}'

Flag = 'Savvy{df263d996281d984952c07998dc54358}'

Flag = 'Savvy{edfbe1afcf9246bb0d40eb4d8027d90f}'

Flag = 'Savvy{2e65f2f2fdaf6c699b223c61b1b5ab89}'

Flag = 'Savvy{e94550c93cd70fe748e6982b3439ad3b}'

Flag = 'Savvy{5c572eca050594c7bc3c36e7e8ab9550}'

Flag = 'Savvy{0537fb40a68c18da59a35c2bfe1ca554}'

Flag = 'Savvy{5f0f5e5f33945135b874349cfbed4fb9}'

Flag = 'Savvy{185e65bc40581880c4f2c82958de8cfe}'

Flag = 'Savvy{8d317bdcf4aafcfc22149d77babee96d}'

Flag = 'Savvy{e49b8b4053df9505e1f48c3a701c0682}'

Flag = 'Savvy{b056eb1587586b71e2da9acfe4fbd19e}'

Flag = 'Savvy{b137fdd1f79d56c7edf3365fea7520f2}'

Flag = 'Savvy{912d2b1c7b2826caf99687388d2e8f7c}'

Flag = 'Savvy{a1d33d0dfec820b41b54430b50e96b5c}'

Flag = 'Savvy{6f2268bd1d3d3ebaabb04d6b5d099425}'

Flag = 'Savvy{872488f88d1b2db54d55bc8bba2fad1b}'

Flag = 'Savvy{ccb0989662211f61edae2e26d58ea92f}'

Flag = 'Savvy{2823f4797102ce1a1aec05359cc16dd9}'

Flag = 'Savvy{470e7a4f017a5476afb7eeb3f8b96f9b}'

Flag = 'Savvy{bf62768ca46b6c3b5bea9515d1a1fc45}'

Flag = 'Savvy{fa14d4fe2f19414de3ebd9f63d5c0169}'

Flag = 'Savvy{2ca65f58e35d9ad45bf7f3ae5cfd08f1}'

Flag = 'Savvy{88ae6372cfdc5df69a976e893f4d554b}'

Flag = 'Savvy{06997f04a7db92466a2baa6ebc8b872d}'

Flag = 'Savvy{eefc9e10ebdc4a2333b42b2dbb8f27b6}'

Flag = 'Savvy{5807a685d1a9ab3b599035bc566ce2b9}'

Flag = 'Savvy{d840cc5d906c3e9c84374c8919d2074e}'

Flag = 'Savvy{959a557f5f6beb411fd954f3f34b21c3}'

Flag = 'Savvy{f2201f5191c4e92cc5af043eebfd0946}'

Flag = 'Savvy{3a835d3215755c435ef4fe9965a3f2a0}'

Flag = 'Savvy{288cc0ff022877bd3df94bc9360b9c5d}'

Flag = 'Savvy{4ea06fbc83cdd0a06020c35d50e1e89a}'

Flag = 'Savvy{b7ee6f5f9aa5cd17ca1aea43ce848496}'

Flag = 'Savvy{e57c6b956a6521b28495f2886ca0977a}'

Flag = 'Savvy{86b122d4358357d834a87ce618a55de0}'

Flag = 'Savvy{4e0928de075538c593fbdabb0c5ef2c3}'

Flag = 'Savvy{c0f168ce8900fa56e57789e2a2f2c9d0}'

Flag = 'Savvy{8c6744c9d42ec2cb9e8885b54ff744d0}'

Flag = 'Savvy{f1c1592588411002af340cbaedd6fc33}'

Flag = 'Savvy{e07413354875be01a996dc560274708e}'

Flag = 'Savvy{67d96d458abdef21792e6d8e590244e7}'

Flag = 'Savvy{a8e864d04c95572d1aece099af852d0a}'

Flag = 'Savvy{7143d7fbadfa4693b9eec507d9d37443}'

Flag = 'Savvy{72da7fd6d1302c0a159f6436d01e9eb0}'

Flag = 'Savvy{6e0721b2c6977135b916ef286bcb49ec}'

Flag = 'Savvy{fc8001f834f6a5f0561080d134d53d29}'

Flag = 'Savvy{4b04a686b0ad13dce35fa99fa4161c65}'

Flag = 'Savvy{61b4a64be663682e8cb037d9719ad8cd}'

Flag = 'Savvy{3621f1454cacf995530ea53652ddf8fb}'

Flag = 'Savvy{c15da1f2b5e5ed6e6837a3802f0d1593}'

Flag = 'Savvy{68053af2923e00204c3ca7c6a3150cf7}'

Flag = 'Savvy{2dace78f80bc92e6d7493423d729448e}'

Flag = 'Savvy{df7f28ac89ca37bf1abd2f6c184fe1cf}'

Flag = 'Savvy{96ea64f3a1aa2fd00c72faacf0cb8ac9}'

Flag = 'Savvy{da8ce53cf0240070ce6c69c48cd588ee}'

Flag = 'Savvy{82489c9737cc245530c7a6ebef3753ec}'

Flag = 'Savvy{7c590f01490190db0ed02a5070e20f01}'

Flag = 'Savvy{35cf8659cfcb13224cbd47863a34fc58}'

Flag = 'Savvy{beb22fb694d513edcf5533cf006dfeae}'

Flag = 'Savvy{9e3cfc48eccf81a0d57663e129aef3cb}'

Flag = 'Savvy{28267ab848bcf807b2ed53c3a8f8fc8a}'

Flag = 'Savvy{7a53928fa4dd31e82c6ef826f341daec}'

Flag = 'Savvy{1905aedab9bf2477edc068a355bba31a}'

Flag = 'Savvy{1141938ba2c2b13f5505d7c424ebae5f}'

Flag = 'Savvy{1aa48fc4880bb0c9b8a3bf979d3b917e}'

Flag = 'Savvy{dc5689792e08eb2e219dce49e64c885b}'

Flag = 'Savvy{846c260d715e5b854ffad5f70a516c88}'

Flag = 'Savvy{d58072be2820e8682c0a27c0518e805e}'

Flag = 'Savvy{6e7b33fdea3adc80ebd648fffb665bb8}'

Flag = 'Savvy{a8ecbabae151abacba7dbde04f761c37}'

Flag = 'Savvy{32b30a250abd6331e03a2a1f16466346}'

Flag = 'Savvy{b6edc1cd1f36e45daf6d7824d7bb2283}'

Flag = 'Savvy{670e8a43b246801ca1eaca97b3e19189}'

Flag = 'Savvy{81e74d678581a3bb7a720b019f4f1a93}'

Flag = 'Savvy{e0cf1f47118daebc5b16269099ad7347}'

Flag = 'Savvy{96b9bff013acedfb1d140579e2fbeb63}'

Flag = 'Savvy{71ad16ad2c4d81f348082ff6c4b20768}'

Flag = 'Savvy{43fa7f58b7eac7ac872209342e62e8f1}'

Flag = 'Savvy{31839b036f63806cba3f47b93af8ccb5}'

Flag = 'Savvy{f0adc8838f4bdedde4ec2cfad0515589}'

Flag = 'Savvy{3b5dca501ee1e6d8cd7b905f4e1bf723}'

Flag = 'Savvy{e2a2dcc36a08a345332c751b2f2e476c}'

Flag = 'Savvy{4558dbb6f6f8bb2e16d03b85bde76e2c}'

Flag = 'Savvy{afda332245e2af431fb7b672a68b659d}'

Flag = 'Savvy{632cee946db83e7a52ce5e8d6f0fed35}'

Flag = 'Savvy{677e09724f0e2df9b6c000b75b5da10d}'

Flag = 'Savvy{d554f7bb7be44a7267068a7df88ddd20}'

Flag = 'Savvy{795c7a7a5ec6b460ec00c5841019b9e9}'

Flag = 'Savvy{fa3a3c407f82377f55c19c5d403335c7}'

Flag = 'Savvy{c2626d850c80ea07e7511bbae4c76f4b}'

Flag = 'Savvy{ce78d1da254c0843eb23951ae077ff5f}'

Flag = 'Savvy{8e82ab7243b7c66d768f1b8ce1c967eb}'

Flag = 'Savvy{e0ec453e28e061cc58ac43f91dc2f3f0}'

Flag = 'Savvy{7250eb93b3c18cc9daa29cf58af7a004}'

Flag = 'Savvy{013a006f03dbc5392effeb8f18fda755}'

Flag = 'Savvy{301ad0e3bd5cb1627a2044908a42fdc2}'

Flag = 'Savvy{4d5b995358e7798bc7e9d9db83c612a5}'

Flag = 'Savvy{ab88b15733f543179858600245108dd8}'

Flag = 'Savvy{b0b183c207f46f0cca7dc63b2604f5cc}'

Flag = 'Savvy{f9028faec74be6ec9b852b0a542e2f39}'

Flag = 'Savvy{8f7d807e1f53eff5f9efbe5cb81090fb}'

Flag = 'Savvy{fa83a11a198d5a7f0bf77a1987bcd006}'

Flag = 'Savvy{02a32ad2669e6fe298e607fe7cc0e1a0}'

Flag = 'Savvy{fc3cf452d3da8402bebb765225ce8c0e}'

Flag = 'Savvy{3d8e28caf901313a554cebc7d32e67e5}'

Flag = 'Savvy{e97ee2054defb209c35fe4dc94599061}'

Flag = 'Savvy{b86e8d03fe992d1b0e19656875ee557c}'

Flag = 'Savvy{84f7e69969dea92a925508f7c1f9579a}'

Flag = 'Savvy{f4552671f8909587cf485ea990207f3b}'

Flag = 'Savvy{362e80d4df43b03ae6d3f8540cd63626}'

Flag = 'Savvy{fe8c15fed5f808006ce95eddb7366e35}'

Flag = 'Savvy{1efa39bcaec6f3900149160693694536}'

Flag = 'Savvy{92fb0c6d1758261f10d052e6e2c1123c}'

Flag = 'Savvy{22ac3c5a5bf0b520d281c122d1490650}'

Flag = 'Savvy{aff1621254f7c1be92f64550478c56e6}'

Flag = 'Savvy{f7e9050c92a851b0016442ab604b0488}'

Flag = 'Savvy{addfa9b7e234254d26e9c7f2af1005cb}'

Flag = 'Savvy{8c235f89a8143a28a1d6067e959dd858}'

Flag = 'Savvy{847cc55b7032108eee6dd897f3bca8a5}'

Flag = 'Savvy{a67f096809415ca1c9f112d96d27689b}'

Flag = 'Savvy{2a084e55c87b1ebcdaad1f62fdbbac8e}'

Flag = 'Savvy{fc49306d97602c8ed1be1dfbf0835ead}'

Flag = 'Savvy{f9a40a4780f5e1306c46f1c8daecee3b}'

Flag = 'Savvy{5ec91aac30eae62f4140325d09b9afd0}'

Flag = 'Savvy{19b650660b253761af189682e03501dd}'

Flag = 'Savvy{1fc214004c9481e4c8073e85323bfd4b}'

Flag = 'Savvy{3b3dbaf68507998acd6a5a5254ab2d76}'

Flag = 'Savvy{ca8155f4d27f205953f9d3d7974bdd70}'

Flag = 'Savvy{ede7e2b6d13a41ddf9f4bdef84fdc737}'

Flag = 'Savvy{dd45045f8c68db9f54e70c67048d32e8}'

Flag = 'Savvy{49c9adb18e44be0711a94e827042f630}'

Flag = 'Savvy{22fb0cee7e1f3bde58293de743871417}'

Flag = 'Savvy{aeb3135b436aa55373822c010763dd54}'

Flag = 'Savvy{43feaeeecd7b2fe2ae2e26d917b6477d}'

Flag = 'Savvy{98d6f58ab0dafbb86b083a001561bb34}'

Flag = 'Savvy{51ef186e18dc00c2d31982567235c559}'

Flag = 'Savvy{4b0a59ddf11c58e7446c9df0da541a84}'

Flag = 'Savvy{67d16d00201083a2b118dd5128dd6f59}'

Flag = 'Savvy{352407221afb776e3143e8a1a0577885}'

Flag = 'Savvy{dd8eb9f23fbd362da0e3f4e70b878c16}'

Flag = 'Savvy{d516b13671a4179d9b7b458a6ebdeb92}'

Flag = 'Savvy{1f50893f80d6830d62765ffad7721742}'

Flag = 'Savvy{7504adad8bb96320eb3afdd4df6e1f60}'

Flag = 'Savvy{6c3cf77d52820cd0fe646d38bc2145ca}'

Flag = 'Savvy{210f760a89db30aa72ca258a3483cc7f}'

Flag = 'Savvy{170c944978496731ba71f34c25826a34}'

Flag = 'Savvy{0efe32849d230d7f53049ddc4a4b0c60}'

Flag = 'Savvy{704afe073992cbe4813cae2f7715336f}'

Flag = 'Savvy{7ce3284b743aefde80ffd9aec500e085}'

Flag = 'Savvy{0a113ef6b61820daa5611c870ed8d5ee}'

Flag = 'Savvy{07871915a8107172b3b5dc15a6574ad3}'

Flag = 'Savvy{024d7f84fff11dd7e8d9c510137a2381}'

Flag = 'Savvy{cfbce4c1d7c425baf21d6b6f2babe6be}'

Flag = 'Savvy{c2aee86157b4a40b78132f1e71a9e6f1}'

Flag = 'Savvy{d56b9fc4b0f1be8871f5e1c40c0067e7}'

Flag = 'Savvy{4b0250793549726d5c1ea3906726ebfe}'

Flag = 'Savvy{20aee3a5f4643755a79ee5f6a73050ac}'

Flag = 'Savvy{061412e4a03c02f9902576ec55ebbe77}'

Flag = 'Savvy{5705e1164a8394aace6018e27d20d237}'

Flag = 'Savvy{a64c94baaf368e1840a1324e839230de}'

Flag = 'Savvy{01882513d5fa7c329e940dda99b12147}'

Flag = 'Savvy{acf4b89d3d503d8252c9c4ba75ddbf6d}'

Flag = 'Savvy{892c91e0a653ba19df81a90f89d99bcd}'

Flag = 'Savvy{b6a1085a27ab7bff7550f8a3bd017df8}'

Flag = 'Savvy{aa169b49b583a2b5af89203c2b78c67c}'

Flag = 'Savvy{f47d0ad31c4c49061b9e505593e3db98}'

Flag = 'Savvy{f57a2f557b098c43f11ab969efe1504b}'

Flag = 'Savvy{c8fbbc86abe8bd6a5eb6a3b4d0411301}'

Flag = 'Savvy{621461af90cadfdaf0e8d4cc25129f91}'

Flag = 'Savvy{8b6dd7db9af49e67306feb59a8bdc52c}'

Flag = 'Savvy{a4300b002bcfb71f291dac175d52df94}'

Flag = 'Savvy{e205ee2a5de471a70c1fd1b46033a75f}'

Flag = 'Savvy{b56a18e0eacdf51aa2a5306b0f533204}'

Flag = 'Savvy{2a9d121cd9c3a1832bb6d2cc6bd7a8a7}'

Flag = 'Savvy{8b5040a8a5baf3e0e67386c2e3a9b903}'

Flag = 'Savvy{7634ea65a4e6d9041cfd3f7de18e334a}'

Flag = 'Savvy{24896ee4c6526356cc127852413ea3b4}'

Flag = 'Savvy{23ce1851341ec1fa9e0c259de10bf87c}'

Flag = 'Savvy{da0d1111d2dc5d489242e60ebcbaf988}'

Flag = 'Savvy{1e056d2b0ebd5c878c550da6ac5d3724}'

Flag = 'Savvy{3e89ebdb49f712c7d90d1b39e348bbbf}'

Flag = 'Savvy{6d0f846348a856321729a2f36734d1a7}'

Flag = 'Savvy{430c3626b879b4005d41b8a46172e0c0}'

Flag = 'Savvy{ccc0aa1b81bf81e16c676ddb977c5881}'

Flag = 'Savvy{c4015b7f368e6b4871809f49debe0579}'

Flag = 'Savvy{bea5955b308361a1b07bc55042e25e54}'

Flag = 'Savvy{7fa732b517cbed14a48843d74526c11a}'

Flag = 'Savvy{cbb6a3b884f4f88b3a8e3d44c636cbd8}'

Flag = 'Savvy{1f4477bad7af3616c1f933a02bfabe4e}'

Flag = 'Savvy{d045c59a90d7587d8d671b5f5aec4e7c}'

Flag = 'Savvy{0d0871f0806eae32d30983b62252da50}'

Flag = 'Savvy{1cc3633c579a90cfdd895e64021e2163}'

Flag = 'Savvy{9f53d83ec0691550f7d2507d57f4f5a2}'

Flag = 'Savvy{d2ed45a52bc0edfa11c2064e9edee8bf}'

Flag = 'Savvy{043c3d7e489c69b48737cc0c92d0f3a2}'

Flag = 'Savvy{4daa3db355ef2b0e64b472968cb70f0d}'

Flag = 'Savvy{e820a45f1dfc7b95282d10b6087e11c0}'

Flag = 'Savvy{90794e3b050f815354e3e29e977a88ab}'

Flag = 'Savvy{b7892fb3c2f009c65f686f6355c895b5}'

Flag = 'Savvy{74bba22728b6185eec06286af6bec36d}'

Flag = 'Savvy{3df1d4b96d8976ff5986393e8767f5b2}'

Flag = 'Savvy{8d6dc35e506fc23349dd10ee68dabb64}'

Flag = 'Savvy{92262bf907af914b95a0fc33c3f33bf6}'

Flag = 'Savvy{b55ec28c52d5f6205684a473a2193564}'

Flag = 'Savvy{2f885d0fbe2e131bfc9d98363e55d1d4}'

Flag = 'Savvy{64223ccf70bbb65a3a4aceac37e21016}'

Flag = 'Savvy{4b6538a44a1dfdc2b83477cd76dee98e}'

Flag = 'Savvy{c8c41c4a18675a74e01c8a20e8a0f662}'

Flag = 'Savvy{c4b31ce7d95c75ca70d50c19aef08bf1}'

Flag = 'Savvy{58e4d44e550d0f7ee0a23d6b02d9b0db}'

Flag = 'Savvy{3cef96dcc9b8035d23f69e30bb19218a}'

Flag = 'Savvy{a3d68b461bd9d3533ee1dd3ce4628ed4}'

Flag = 'Savvy{1c1d4df596d01da60385f0bb17a4a9e0}'

Flag = 'Savvy{e6cb2a3c14431b55aa50c06529eaa21b}'

Flag = 'Savvy{9232fe81225bcaef853ae32870a2b0fe}'

Flag = 'Savvy{6395ebd0f4b478145ecfbaf939454fa4}'

Flag = 'Savvy{ef4e3b775c934dada217712d76f3d51f}'

Flag = 'Savvy{168908dd3227b8358eababa07fcaf091}'

Flag = 'Savvy{2ba596643cbbbc20318224181fa46b28}'

Flag = 'Savvy{d240e3d38a8882ecad8633c8f9c78c9b}'

Flag = 'Savvy{0f840be9b8db4d3fbd5ba2ce59211f55}'

Flag = 'Savvy{437d7d1d97917cd627a34a6a0fb41136}'

Flag = 'Savvy{d707329bece455a462b58ce00d1194c9}'

Flag = 'Savvy{5c936263f3428a40227908d5a3847c0b}'

Flag = 'Savvy{1ce927f875864094e3906a4a0b5ece68}'

Flag = 'Savvy{8065d07da4a77621450aa84fee5656d9}'

Flag = 'Savvy{eeb69a3cb92300456b6a5f4162093851}'

Flag = 'Savvy{4e0cb6fb5fb446d1c92ede2ed8780188}'

Flag = 'Savvy{6cfe0e6127fa25df2a0ef2ae1067d915}'

Flag = 'Savvy{8f468c873a32bb0619eaeb2050ba45d1}'

Flag = 'Savvy{e744f91c29ec99f0e662c9177946c627}'

Flag = 'Savvy{89fcd07f20b6785b92134bd6c1d0fa42}'

Flag = 'Savvy{6602294be910b1e3c4571bd98c4d5484}'

Flag = 'Savvy{c22abfa379f38b5b0411bc11fa9bf92f}'

Flag = 'Savvy{ca75910166da03ff9d4655a0338e6b09}'

Flag = 'Savvy{4311359ed4969e8401880e3c1836fbe1}'

Flag = 'Savvy{92977ae4d2ba21425a59afb269c2a14e}'

Flag = 'Savvy{9c01802ddb981e6bcfbec0f0516b8e35}'

Flag = 'Savvy{cc1aa436277138f61cda703991069eaf}'

Flag = 'Savvy{2ab56412b1163ee131e1246da0955bd1}'

Flag = 'Savvy{c32d9bf27a3da7ec8163957080c8628e}'

Flag = 'Savvy{d79aac075930c83c2f1e369a511148fe}'

Flag = 'Savvy{287e03db1d99e0ec2edb90d079e142f3}'

Flag = 'Savvy{fec8d47d412bcbeece3d9128ae855a7a}'

Flag = 'Savvy{6aab1270668d8cac7cef2566a1c5f569}'

Flag = 'Savvy{d93ed5b6db83be78efb0d05ae420158e}'

Flag = 'Savvy{54a367d629152b720749e187b3eaa11b}'

Flag = 'Savvy{fe7ee8fc1959cc7214fa21c4840dff0a}'

Flag = 'Savvy{df6d2338b2b8fce1ec2f6dda0a630eb0}'

Flag = 'Savvy{9908279ebbf1f9b250ba689db6a0222b}'

Flag = 'Savvy{a1140a3d0df1c81e24ae954d935e8926}'

Flag = 'Savvy{4fac9ba115140ac4f1c22da82aa0bc7f}'

Flag = 'Savvy{692f93be8c7a41525c0baf2076aecfb4}'

Flag = 'Savvy{860320be12a1c050cd7731794e231bd3}'

Flag = 'Savvy{7b13b2203029ed80337f27127a9f1d28}'

Flag = 'Savvy{934815ad542a4a7c5e8a2dfa04fea9f5}'

Flag = 'Savvy{2bcab9d935d219641434683dd9d18a03}'

Flag = 'Savvy{0b8aff0438617c055eb55f0ba5d226fa}'

Flag = 'Savvy{ec5aa0b7846082a2415f0902f0da88f2}'

Flag = 'Savvy{9ab0d88431732957a618d4a469a0d4c3}'

Flag = 'Savvy{b706835de79a2b4e80506f582af3676a}'

FLAG_PREFIX = "flag{%s}"

# Given phrase
phrase = "Tdf Ga Lal Vlg Subr"
print("Unravel the Captain’s dying whispers to find the key to the Triangle and claim your soul.")

# Calculate correct pin dynamically
words = phrase.strip().split()
correct_pin = "".join(str(len(word)) for word in words)

# Correct hash for verification
target_hash = hashlib.sha256(correct_pin.encode("utf-8")).hexdigest()

# Ask user for pin
user_pin = input("Speak the Captain's dying wish... ").strip()

# Hash the user input
user_hash = hashlib.sha256(user_pin.encode("utf-8")).hexdigest()

# Verify
if user_hash == target_hash:
    print("You have found the Matador's hidden truth")
    Flag = "Savvy{7h3_$34_8310ng$_70_7h3_d34d}"
    print("Flag =", Flag)
else:
    print("Bad pin!")
    print("DEBUG: Calculated Hash:", user_hash)
    print("DEBUG: Target Hash:    ", target_hash)
