PRINTER DOCUMENTATION
=====================

Service documentation directory.

This directory contains:
- User manuals
- Technical specifications
- Service reports
- Maintenance logs

Note: Some service reports generated during maintenance 
may be encrypted for security purposes. Check system 
logs for access information.

For support, contact: support@fray.local
